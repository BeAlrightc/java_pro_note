package com.glc.service;


import com.glc.pejo.User;

public interface UserService {

    /**
     * @param user
     * @return
     */
    public User login(User user);


}
