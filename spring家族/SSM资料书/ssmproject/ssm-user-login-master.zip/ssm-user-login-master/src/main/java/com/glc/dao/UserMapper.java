package com.glc.dao;


import com.glc.pejo.User;

public interface UserMapper {

    /**
     * 登录
     *
     * @param user
     * @return
     */
    public User login(User user);
}
