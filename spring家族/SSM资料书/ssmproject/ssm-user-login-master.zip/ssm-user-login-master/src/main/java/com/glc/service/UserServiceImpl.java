package com.glc.service;

import javax.annotation.Resource;

import com.glc.dao.UserMapper;
import com.glc.pejo.User;

import com.glc.service.UserService;
import org.springframework.stereotype.Service;




@Service("userService")
public class UserServiceImpl implements UserService {

    @Resource
    private UserMapper userMapper;

    @Override
    public User login(User user) {
        return userMapper.login(user);
    }

}
