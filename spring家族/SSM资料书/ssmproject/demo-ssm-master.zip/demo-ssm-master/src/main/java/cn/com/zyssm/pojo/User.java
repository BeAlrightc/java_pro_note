package cn.com.zyssm.pojo;

public class User {
    private int  id;
    private String jName;
    private String jPass;

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getjName() {
        return jName;
    }
    public void setjName(String jName) {
        this.jName = jName;
    }
    public String getjPass() {
        return jPass;
    }
    public void setjPass(String jPass) {
        this.jPass = jPass;
    }
    @Override
    public String toString() {
        return "Teacher [id=" + id + ", jName=" + jName + ", jPass=" + jPass + "]";
    }

}
