package cn.com.zyssm.contorller;

import cn.com.zyssm.pojo.User;
import cn.com.zyssm.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequestMapping("/user")
public class UserContorller {
    @Resource
    private  UserService userService;

    @RequestMapping("/login")
    public String login(){
        return "login";
    }

    @RequestMapping("/login.do")
    public String addUser(String name,String pass,Model model){
        User user=new User();
        user.setjName(name);
        user.setjPass(pass);
        int num=userService.addUser(user);
        if (num>0){
            return "redirect:/user/login" ;
        }else {
            return "redirect:index";
        }
    }
    @RequestMapping("/login.doo")
    public String index(){
        return "index";
    }

    @RequestMapping("/userList")
    public String UserList(Model model){
        List<User> list=userService.selectUserList();
        model.addAttribute("userlist",list);
        return "userList";
    }
    @RequestMapping("/index.do")
    public String indexDo(String name,String pass){
        User user=userService.selectUser(name,pass);
        if (user!=null){
            return "redirect:/user/userList" ;
        }else {
            return "login";
        }

    }
}
