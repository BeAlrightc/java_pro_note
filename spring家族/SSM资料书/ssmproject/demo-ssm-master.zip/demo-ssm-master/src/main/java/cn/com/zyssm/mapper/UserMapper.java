package cn.com.zyssm.mapper;

import cn.com.zyssm.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserMapper {
    public List<User> selectUserList();
    public int addUser(User user);
    public User selectUser(@Param("jName") String jName,@Param("jPass")  String jPass);

}
