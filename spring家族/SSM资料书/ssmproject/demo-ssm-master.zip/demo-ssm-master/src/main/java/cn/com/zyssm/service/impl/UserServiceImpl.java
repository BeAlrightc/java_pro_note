package cn.com.zyssm.service.impl;

import cn.com.zyssm.mapper.UserMapper;
import cn.com.zyssm.pojo.User;
import cn.com.zyssm.service.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service
public class UserServiceImpl implements UserService {

    @Resource
    UserMapper userMapper;

    @Override
    public List<User> selectUserList() {
        return userMapper.selectUserList();
    }

    @Override
    public int addUser(User user) {
        return userMapper.addUser(user);
    }

    @Override
    public User selectUser(String jName, String jPass) {
        return userMapper.selectUser(jName,jPass);
    }


}
