package cn.com.zyssm.service;

import cn.com.zyssm.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserService {
    public List<User> selectUserList();
    public int addUser(User user);
    public User selectUser(@Param("jName") String jName, @Param("jPass")  String jPass);
}
