package com.service;

import com.po.UserLogin;

public interface UserLoginService {
    public UserLogin findUser(UserLogin userLogin);
}
