package com.shopclass.service;

import com.shopclass.VO.DetailsVO;
import com.shopclass.entity.Details;

public interface DetailsService {
    DetailsVO findDescription(Integer id);

}
