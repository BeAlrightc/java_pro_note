package com.wrx.service;

import com.wrx.pojo.RespBean;

public interface AdminService {
    public RespBean login();
}
